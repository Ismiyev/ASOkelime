### Telegram Kelime Oyunu @vusaliw
📝
## Deploy to Heroku

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Nihatttm/kelimet-retv1-2)
