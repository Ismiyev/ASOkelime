from pyrogram.types import InlineKeyboardButton
from pyrogram.types import InlineKeyboardMarkup

kanal = InlineKeyboardMarkup([
    [InlineKeyboardButton("ℹ️ Rəsmi Kanal " , url= "https://t.me/RichResmi")]
])

