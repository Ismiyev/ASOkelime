from kelime_bot import bot

if __name__ == "__main__":
    bot.run()
